package eStoreSearch;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;

import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BoxLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.io.File;
import java.awt.*;
import javax.swing.*;

public class MyFrame extends JFrame implements ActionListener 
{
    JButton aButton;
    JButton sButton;
    JButton qButton;

    JButton addButton;
    JButton searchButton;
    JButton addResetButton;
    JButton searchResetButton;

    JPanel addPanel;
    JPanel addPanel2;
    JPanel addPanel3;
    JPanel searchPanel;
    JPanel searchPanel2;
    JPanel searchPanel3;
    JPanel grayPanel2;

    JTextField idTF;
    JTextField descriptionTF;
    JTextField priceTF;
    JTextField yearTF;

    JTextField authorTF;
    JTextField publisherTF;
    JTextField makerTF;

    JTextField idTF2;
    JTextField descriptionTF2;
    JTextField startYearTF;
    JTextField endYearTF;

    JComboBox comboBox;

    JLabel idLabel;
    JLabel descriptionLabel;
    JLabel priceLabel;
    JLabel yearLabel;

    JLabel authorLabel;
    JLabel publisherLabel;

    JLabel makerLabel;


    JLabel idLabel2;
    JLabel descriptionLabel2;
    JLabel startYearLabel;
    JLabel endYearLabel;

    ArrayList<Product> Products;
    HashMap<String, ArrayList<Integer>> HashMap;

    String id;
    String description;
    String sPrice;
    float price;
    String sYear;
    int year;
    String author;
    String publisher;
    String maker;
    String sStartYear;
    String sEndYear;
    
    String productFile;

    JTextArea textArea;
    JScrollPane scrollPane;
    JTextArea textArea2;
    JScrollPane scrollPane2;

    /**
     * Sets product list
     * @param list      list of products
     */
    public void setList(ArrayList<Product> list) {
        this.Products = list;
    }

    /**
     * Sets Hash Map
     * @param map       Hash Map
     */
    public void setMap(HashMap<String, ArrayList<Integer>> map) {
        this.HashMap = map;
    }

    /**
     * Prints product list
     * @param ProductList   List of products
     */
    public void printProductList(ArrayList<Product> ProductList) {
        for(int i = 0; i < ProductList.size(); i++)
        {
            textArea2.append(Products.get(i).toString());
        }
    }

    /**
     * Checks validity of new added product
     * @param sProductID    String product ID
     * @param description   Product description
     * @param sPrice        Product price
     * @param sYear         String year
     * @return              if product is valid to add
     */
    public int addValidityCheck(String sProductID, String description, String sPrice, String sYear) {
        int idFlag = 0;
        int descriptionFlag = 0;
        int priceFlag = 0;
        int yearFlag = 0;
        int testGood = 0;
        int goodFlag = 0;
        int testID = 0;
        float testPrice = 0;
        int testYear = 0;
        try
        {
            testID = Integer.parseInt(sProductID);
            idFlag = 1;
        } 
        catch (Exception e) 
        {
            
            textArea.append("Error: couldn't parse id\n");
            idFlag = 0;
        }
                            
        if(sProductID.length() != 6) 
        {
            textArea.append("Error: wrong number of digits (6)\n");
            idFlag = 0;
        } 
        else if (sProductID.length() == 6 && idFlag == 1) 
        {
            for(int i = 0; i < Products.size(); i++)
            {
                if (Products.get(i).getProductID(sProductID) == 1)
                {
                    textArea.append("We cannot accept this product ID as it already is in use\n");   
                    idFlag = 0; 
                } else {                                       
                    idFlag = 1;
                }
            }   

        }

        if(sProductID.length() == 6 && goodFlag == 1)
        {
            idFlag = 1;
        } else {
            idFlag= 0;
        }

        if(description.length() == 0) 
        {
            textArea.append("You need to print something in the description\n");
            descriptionFlag = 0;
        } else {
            descriptionFlag = 1;
        }

        try
        {
        testPrice = Float.parseFloat(sPrice);
        priceFlag = 1;
        } 
        catch (Exception e) 
        {
            textArea.append("Error: couldn't parse price\n");
        priceFlag = 0;
        }

        try
        {
        testYear = Integer.parseInt(sYear);
        yearFlag = 1;
        } catch (Exception e) 
        {
            textArea.append("Error: couldn't parse year\n");
            yearFlag = 0;
        }

        if(testYear > 9999 || testYear < 1000) 
        {
            textArea.append("Error: Not a valid year\n");
            yearFlag = 0;
        }

        testGood = idFlag + descriptionFlag + priceFlag + yearFlag;

        if (testGood == 3)
        {
            goodFlag = 1;
        } 
        else {
            goodFlag = 0;
        }

        return goodFlag;
    }

    /*3 separate functions
        one for id
        one for start year
        one for end year

        if not 0
        if 
        every error returns a -1
        no error adds to a flag
        if 3 then gucci

        if 0 is returned add 1 to the flag
        */

    /**
     * Checks if ID is valid for search
     * @param id    Product ID
     * @return      if product id is valid
     */
    public int checkID(String id)
    {
        int check = 0;
        int testID = 0;
        if(id.length() != 0)
        {
            if(id.length() != 6)
            {
                textArea2.append("Wrong id size\n");
                check = 1;
            }

            try
            {
                testID = Integer.parseInt(id);
                if(testID < 0)
                {
                    check = 1;
                } else {
                    check = 0;
                }

            }
            catch (Exception e) {
                textArea2.append("Can't parse ID\n");
                check = 1;
            }
        } else {
            check = 0;
        }

        

        return check;
    }

    /**
     * Checks to see if start year is valid
     * @param sStartYear    String start year
     * @return              if start year is valid
     */
    public int startYearCheck(String sStartYear)
    {
        int check = 0;
        int testStartYear = 0;
        if(sStartYear.length() != 0)
        {
            try
            {
                testStartYear = Integer.parseInt(sStartYear);
                if(testStartYear < 1000 || testStartYear > 9999)
                {
                    check = 1;
                }
            }
            catch (Exception e) {
                textArea2.append("Invalid Start Year\n");
                check = 1;
            }
        } else {
            check = 0;
        }
        return check;
    }

    /**
     * Checks if end year is valid
     * @param sEndYear      String end year
     * @return              if end year is valid
     */
    public int endYearCheck(String sEndYear)
    {
        int check = 0;
        int testEndYear = 0;
        if(sEndYear.length() != 0)
        {
            try
            {
                testEndYear = Integer.parseInt(sEndYear);
                if(testEndYear < 1000 || testEndYear > 9999)
                {
                    
                    check = 1;
                }
            }
            catch (Exception e) {
                textArea2.append("Invalid End Year");
                check = 1;
            }
        } else {
            check = 0;
        }
        return check;
    }

 

    MyFrame(HashMap<String,ArrayList<Integer>> sHash, ArrayList<Product> sProduct, String file) 
    {

        productFile = file;
        setList(sProduct);
        setMap(sHash);
        //printProductList(Products);

        textArea = new JTextArea();
        textArea.setText("Message:\n");
        textArea.setBounds(100, 300, 200, 100);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setVisible(false);
        textArea.setEditable(false);

        textArea2 = new JTextArea();
        textArea2.setText("Results:\n");
        textArea2.setBounds(100, 700, 200, 80);
        textArea2.setLineWrap(true);
        textArea2.setWrapStyleWord(true);
        textArea2.setVisible(false);
        textArea2.setEditable(false);

        scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500,300));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setVisible(false);

        scrollPane2 = new JScrollPane(textArea2);
        scrollPane2.setPreferredSize(new Dimension(500,300));
        scrollPane2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane2.setVisible(false);

        idTF = new JTextField();
        idTF.setPreferredSize(new Dimension(160,20));
        idTF.setVisible(false);

        descriptionTF = new JTextField();
        descriptionTF.setPreferredSize(new Dimension(160,20));
        descriptionTF.setVisible(false);

        priceTF = new JTextField();
        priceTF.setPreferredSize(new Dimension(160,20));
        priceTF.setVisible(false);

        yearTF = new JTextField();
        yearTF.setPreferredSize(new Dimension(160,20));
        yearTF.setVisible(false);

        authorTF = new JTextField();
        authorTF.setPreferredSize(new Dimension(160,20));
        authorTF.setVisible(false);

        publisherTF = new JTextField();
        publisherTF.setPreferredSize(new Dimension(160,20));
        publisherTF.setVisible(false);

        makerTF = new JTextField();
        makerTF.setPreferredSize(new Dimension(160,20));
        makerTF.setVisible(false);

        idTF2 = new JTextField();
        idTF2.setPreferredSize(new Dimension(160,20));
        idTF2.setVisible(false);

        descriptionTF2 = new JTextField();
        descriptionTF2.setPreferredSize(new Dimension(160,20));
        descriptionTF2.setVisible(false);

        startYearTF = new JTextField();
        startYearTF.setPreferredSize(new Dimension(160,20));
        startYearTF.setVisible(false);

        endYearTF = new JTextField();
        endYearTF.setPreferredSize(new Dimension(160,20));
        endYearTF.setVisible(false);

        //label
        JLabel welcomeLabel = new JLabel();
        JLabel instructionLabel = new JLabel();

        idLabel = new JLabel();
        descriptionLabel = new JLabel();
        priceLabel = new JLabel();
        yearLabel = new JLabel();
        authorLabel = new JLabel();
        publisherLabel = new JLabel();
        makerLabel = new JLabel();

        idLabel2 = new JLabel();
        descriptionLabel2 = new JLabel();
        startYearLabel = new JLabel();
        endYearLabel = new JLabel();

        //GridLayout gl = new GridLayout(4,1); // 4 rows, 2 columns

        welcomeLabel.setText("Welcome to EStoreSearch");
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setVerticalAlignment(JLabel.BOTTOM);
        welcomeLabel.setForeground(new Color(0x000000));
        welcomeLabel.setFont(new Font("MV Boli",Font.PLAIN, 10));

        instructionLabel.setText("Choose a command from the top (Either add a product, search a product, or quit)");
        instructionLabel.setHorizontalAlignment(JLabel.CENTER);
        instructionLabel.setVerticalAlignment(JLabel.BOTTOM);
        instructionLabel.setForeground(new Color(0x000000));
        instructionLabel.setFont(new Font("MV Boli",Font.PLAIN, 10));

        idLabel.setText("ProductID:");
        idLabel.setVisible(false);
        descriptionLabel.setText("Description:");
        descriptionLabel.setVisible(false);
        priceLabel.setText("Price:");
        priceLabel.setVisible(false);
        yearLabel.setText("Year:");
        yearLabel.setVisible(false);
        authorLabel.setText("Author:");
        authorLabel.setVisible(false);
        publisherLabel.setText("Publisher:");
        publisherLabel.setVisible(false);
        makerLabel.setText("Maker:");
        makerLabel.setVisible(false);

        idLabel2.setText("ProductID:");
        descriptionLabel2.setText("Description:");
        startYearLabel.setText("Start Year:");
        endYearLabel.setText("End Year:");

        //panel
        JPanel grayPanel = new JPanel();
        grayPanel.setBackground(Color.gray);
        grayPanel.setBounds(0,0,750,750);
        
        
        grayPanel2 = new JPanel();
        grayPanel2.setBackground(Color.gray);
        grayPanel2.setBounds(0,110,750,650);
        

        addPanel = new JPanel();
        addPanel.setBackground(Color.white);
        addPanel.setBounds(0,110,500,400);
        addPanel.setLayout(new BoxLayout(addPanel, BoxLayout.PAGE_AXIS));

        String[] products = {"Books", "Electronics"};
        comboBox = new JComboBox(products);
        comboBox.addActionListener(this);
        comboBox.setVisible(false);

        addPanel2 = new JPanel();
        addPanel2.setBackground(Color.lightGray);
        addPanel2.setBounds(400,110,400,400);

        addPanel3 = new JPanel();
        addPanel3.setBackground(Color.black);
        addPanel3.setBounds(20,530,700,180);
        addPanel3.setLayout(new GridLayout(1,1));

        searchPanel = new JPanel();
        searchPanel.setBackground(Color.white);
        searchPanel.setBounds(0,110,500,400);
        searchPanel.setLayout(new BoxLayout(searchPanel, BoxLayout.PAGE_AXIS));

        searchPanel2 = new JPanel();
        searchPanel2.setBackground(Color.black);
        searchPanel2.setBounds(400,110,400,400);

        searchPanel3 = new JPanel();
        searchPanel3.setBackground(Color.lightGray);
        searchPanel3.setBounds(0,500,750,250);

       // setLayout(new BoxLayout(addPanel, BoxLayout.Y_AXIS));

        /*JPanel bluePanel = new JPanel();
        bluePanel.setBackground(Color.blue);
        bluePanel.setBounds(250,0,150,150);

        JPanel greenPanel = new JPanel();
        greenPanel.setBackground(Color.black);
        greenPanel.setBounds(10,10,10,10);*/

        aButton = new JButton();
        aButton.setBounds(150, 50, 100, 50);
        aButton.addActionListener(this);
        aButton.setText("Add");
        aButton.setFocusable(false);
        
        sButton = new JButton();
        sButton.setBounds(350, 50, 100, 50);
        sButton.addActionListener(this);
        sButton.setText("Search");
        sButton.setFocusable(false);

        qButton = new JButton();
        qButton.setBounds(550, 50, 100, 50);
        qButton.addActionListener(this);
        qButton.setText("Quit");
        qButton.setFocusable(false);

        addButton = new JButton();
        addButton.setBounds(550, 100, 200, 100);
        addButton.addActionListener(this);
        addButton.setText("Add");
        addButton.setFocusable(false);
        addButton.setVisible(false);
        
        searchButton = new JButton();
        searchButton.setBounds(550, 100, 200, 100);
        searchButton.addActionListener(this);
        searchButton.setText("Search");
        searchButton.setFocusable(false);
        searchButton.setVisible(false);

        addResetButton = new JButton();
        addResetButton.setBounds(550, 100, 200, 100);
        addResetButton.addActionListener(this);
        addResetButton.setText("Reset");
        addResetButton.setFocusable(false);
        addResetButton.setVisible(false);

        searchResetButton = new JButton();
        searchResetButton.setBounds(550, 100, 200, 100);
        searchResetButton.addActionListener(this);
        searchResetButton.setText("Reset");
        searchResetButton.setFocusable(false);
        searchResetButton.setVisible(false);


        //frame
        //descriptionTF
        
        this.setTitle("EstoreSearch");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(true);
        this.setSize(750,750);                                                          
        this.setVisible(true);
        this.add(aButton);
        this.add(sButton);
        this.add(qButton);
        this.add(grayPanel2);
        this.add(addPanel);
        addPanel3.add(scrollPane);
        addPanel2.add(addButton);
        addPanel2.add(addResetButton);
        addPanel.add(comboBox);
        addPanel.add(idLabel);
        addPanel.add(idTF);
        addPanel.add(descriptionLabel);
        addPanel.add(descriptionTF);
        addPanel.add(priceLabel);
        addPanel.add(priceTF);
        addPanel.add(yearLabel);
        addPanel.add(yearTF);
        addPanel.add(authorLabel);
        addPanel.add(authorTF);
        addPanel.add(publisherLabel);
        addPanel.add(publisherTF);
        addPanel.add(makerLabel);
        addPanel.add(makerTF);
        this.add(addPanel2);
        this.add(addPanel3);
        this.add(searchPanel);
        searchPanel3.add(scrollPane2);
        searchPanel2.add(searchButton);
        searchPanel2.add(searchResetButton);
        searchPanel.add(idLabel2);
        searchPanel.add(idTF2);
        searchPanel.add(descriptionLabel2);
        searchPanel.add(descriptionTF2);
        searchPanel.add(startYearLabel);
        searchPanel.add(startYearTF);
        searchPanel.add(endYearLabel);
        searchPanel.add(endYearTF);
        this.add(searchPanel2);
        this.add(searchPanel3);
        this.add(grayPanel);
        grayPanel.add(welcomeLabel);
        grayPanel.add(instructionLabel);
        
        //this.add(bluePanel);
        //this.add(greenPanel);
        //this.add(label);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == comboBox) {
            if (comboBox.getSelectedItem().equals("Electronics")) {
                authorTF.setVisible(false);
                authorLabel.setVisible(false);
                publisherTF.setVisible(false);
                publisherLabel.setVisible(false);
                makerLabel.setVisible(true);
                makerTF.setVisible(true);
                
            } else if (comboBox.getSelectedItem().equals("Books")) {
                authorLabel.setVisible(true);
                authorTF.setVisible(true);
                publisherLabel.setVisible(true);
                publisherTF.setVisible(true);
                makerLabel.setVisible(false);
                makerTF.setVisible(false);
                
            }
        }

        if(e.getSource() == aButton)
        {
            comboBox.setSelectedItem("Books");
            addPanel.setVisible(true);
            addPanel2.setVisible(true);
            addPanel3.setVisible(true);
            searchPanel.setVisible(false);
            searchPanel2.setVisible(false);
            searchPanel3.setVisible(false);
            grayPanel2.setVisible(false);
            comboBox.setVisible(true);
            idLabel.setVisible(true);
            idTF.setVisible(true);
            descriptionLabel.setVisible(true);
            descriptionTF.setVisible(true);
            priceLabel.setVisible(true);
            priceTF.setVisible(true);
            yearLabel.setVisible(true);
            yearTF.setVisible(true);
            authorLabel.setVisible(true);
            authorTF.setVisible(true);
            publisherLabel.setVisible(true);
            publisherTF.setVisible(true);
            addButton.setVisible(true);
            searchButton.setVisible(false);
            addResetButton.setVisible(true);
            searchResetButton.setVisible(false);
            textArea.setVisible(true);
            scrollPane.setVisible(true);
            

        } 
        else if(e.getSource() == sButton)
        {
            addPanel.setVisible(false);
            addPanel2.setVisible(false);
            addPanel3.setVisible(false);
            searchPanel.setVisible(true);
            searchPanel2.setVisible(true);
            searchPanel3.setVisible(true);
            grayPanel2.setVisible(false);
            idLabel.setVisible(true);
            idTF2.setVisible(true);
            descriptionLabel.setVisible(true);
            descriptionTF2.setVisible(true);
            startYearLabel.setVisible(true);
            startYearTF.setVisible(true);
            endYearLabel.setVisible(true);
            endYearTF.setVisible(true);
            addButton.setVisible(false);
            searchButton.setVisible(true);
            searchResetButton.setVisible(true);
            addResetButton.setVisible(false);
            textArea2.setVisible(true);
            scrollPane2.setVisible(true);
        } 
        else if(e.getSource() == qButton)
        {
            //printProductList(Products);
            System.exit(0);
        }

        if(e.getSource() == addButton) {
            id = idTF.getText();
            //System.out.println(id);
            description = descriptionTF.getText();
            //System.out.println(description);
            sPrice = priceTF.getText();
            //price = Float.parseFloat(sPrice);
            //System.out.println(price);
            sYear = yearTF.getText();
            //year = Integer.parseInt(sYear);
            //System.out.println(year);

            //reset
            

            if (addValidityCheck(id, description, sPrice, sYear) == 1) {
                price = Float.parseFloat(sPrice);
                year = Integer.parseInt(sYear);
                if ((comboBox.getSelectedItem().equals("Books"))) {
                    author = authorTF.getText();
                    publisher = publisherTF.getText();
                    Products.add(new Book("Book", id, description, price, year, author, publisher));
                    textArea.setText("BOOK ADDED SUCCESSFULLY!\n");
                } else {
                    maker = makerTF.getText();
                    Products.add(new Electronic("Electronic", id, description, price, year, maker));
                    textArea.setText("ELECTRONIC ADDED SUCCESSFULLY!\n");
                }

                PrintWriter fileWriter = null;
                File myFile = null;
                try{
                    myFile = new File(productFile);
                    fileWriter = new PrintWriter(new FileOutputStream(myFile,true));
                } catch (FileNotFoundException something) {
                    System.out.println("File does not exist");
                    System.exit(0);
                }

                
                    if(comboBox.getSelectedItem().equals("Books"))
                    {
                        fileWriter.println("type = Book");
                    } else if(comboBox.getSelectedItem().equals("Electronics")){
                        fileWriter.println("type = Electronic");
                    }

                    fileWriter.println("productID = \"" + id + "\"");
                    fileWriter.println("description = \"" + description + "\"");
                    fileWriter.println("price = \"" + price + "\"");
                    fileWriter.println("year = \"" + year + "\"");

                    if(comboBox.getSelectedItem().equals("Books"))
                    {
                        fileWriter.println("author = \"" + author + "\"");
                        fileWriter.println("publisher = \"" + publisher + "\"");
                    } else if(comboBox.getSelectedItem().equals("Electronics"))
                    {
                        fileWriter.println("maker = \"" + maker + "\"");
                    }
                
                fileWriter.close();
            }
            

            

        }

        if(e.getSource() == searchButton)
        {
            id = idTF2.getText();
            description = descriptionTF2.getText();
            sStartYear = startYearTF.getText();
            sEndYear = endYearTF.getText();
            int specificYearFlag = 0;
            int startYear = 0;
            int endYear = 0;
            int goodFlag = 0;
        
            goodFlag = 0;
            if(checkID(id) == 0)
            {
                goodFlag++;
            } 

            if(startYearCheck(sStartYear) == 0)
            {
                goodFlag++;
            }

            if(endYearCheck(sEndYear) == 0)
            {
                goodFlag++;
            }

            
           

            if(goodFlag == 3)
            {
                //startYear = Integer.parseInt(sStartYear);
                //endYear = Integer.parseInt(sEndYear);

                if(sStartYear.length() == 0) {
                    startYear = 1000;
                } else {
                    startYear = Integer.parseInt(sStartYear);
                }

                if(sEndYear.length() == 0) {
                    endYear = 9999;
                } else {
                    endYear = Integer.parseInt(sEndYear);
                }


                for(int i = 0; i < Products.size(); i++) {
                    
                    if(Products.get(i).searchProduct(id, description, startYear, endYear) >= 3) {
                        //textArea.setText();
                        textArea2.append(Products.get(i).toString());
                    }
                }
                
                
            }
            
        }

        if(e.getSource() == addResetButton)
        {
            idTF.setText("");
            descriptionTF.setText("");
            priceTF.setText("");
            yearTF.setText("");

            authorTF.setText("");
            publisherTF.setText("");
            makerTF.setText("");
            textArea.setText("Message:\n");
        }

        if(e.getSource() == searchResetButton)
        {
            idTF2.setText("");
            descriptionTF2.setText("");
            startYearTF.setText("");
            endYearTF.setText("");
            textArea2.setText("Results:\n");
            
        }

        


        

    }
}


package eStoreSearch;
import java.lang.*;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Font;
import javax.swing.JLabel;


class EStoreSearch 
{
    public static void main(String[] args)
    {
        
        
        ArrayList<Product> Products = new ArrayList<Product>();
        HashMap<String, ArrayList<Integer>> keywordsMap = new HashMap<String, ArrayList<Integer>>();

        

        String currentLine = "";
        String productType = "";
        String productID = "";
        String productDescription = "";
        String readPrice = "";
        float productPrice = 0;
        String readYear = "";
        int productYear = 0;
        String author = "";
        String publisher = "";
        String maker = "";
        int count = 0;
        int addFlag = 0;
        int productCount = 0;
        

        File fileReader = null;
        Scanner scanner = null;
        System.out.println(args[0]);
        try
        {
            fileReader = new File(args[0]);
            scanner = new Scanner(fileReader);
            System.out.println(fileReader.getAbsolutePath());
        } catch (Exception e) {
            System.out.println("Could not open");
        }


        while(scanner.hasNextLine()) 
        {
            currentLine = scanner.nextLine();
            StringTokenizer tokens = new StringTokenizer(currentLine, "=");
            String token1 = tokens.nextToken();
            String token2 = tokens.nextToken();

            if(token1.toLowerCase().contains("type")) {
                productType = token2.substring(2,token2.length()-1);
                count++;
            }
            else if(token1.toLowerCase().contains("productid")) {
                productID = token2.substring(2,token2.length()-1);
                count++;
            }
            else if(token1.toLowerCase().contains("description")) {
                productDescription = token2.substring(2,token2.length()-1);
                count++;
            }
            else if(token1.toLowerCase().contains("price")) {
                readPrice = token2.substring(2,(token2.length()-1));
                productPrice = Float.parseFloat(readPrice);
                count++;
            }
            else if(token1.toLowerCase().contains("year")) {
                readYear = token2.substring(2,(token2.length()-1));
                productYear = Integer.parseInt(readYear);
                count++;
            }
            else if(token1.toLowerCase().contains("author")) {
                author = token2.substring(2,token2.length()-1);
                count++;
            }
            else if(token1.toLowerCase().contains("publisher")) {
                publisher = token2.substring(2,token2.length()-1);
                count++;
            }
            else if(token1.toLowerCase().contains("maker")) {
                maker = token2.substring(2,token2.length()-1);
                count++;
            }
            
            if(count == 7) {
                Products.add(new Book(productType, productID, productDescription, productPrice, productYear, author, publisher));
                count = 0;
                addFlag = 1;
            }
            else if(productType.toLowerCase().contains("electronics") && count == 6) {
                Products.add(new Electronic(productType, productID, productDescription, productPrice, productYear, maker));
                count = 0;
                addFlag = 1;
            }

            if(addFlag == 1)
            {
                StringTokenizer keywordsTokenizer = new StringTokenizer(productDescription);
                int tokenCount = keywordsTokenizer.countTokens();
                String keywordsTokens[] = new String[tokenCount];

                for(int i = 0; i < tokenCount; i++)
                {
                    keywordsTokens[i] = keywordsTokenizer.nextToken();
                    if(keywordsMap.containsKey(keywordsTokens[i]))
                    {
                        keywordsMap.get(keywordsTokens[i]).add(productCount);
                    } else {
                        ArrayList<Integer> temp = new ArrayList<Integer>();
                        temp.add(productCount);
                        keywordsMap.put(keywordsTokens[i].toLowerCase(),temp);
                    }
                }
                productCount++;
                addFlag = 0;
            }

        }
        scanner.close();
        

        /*for(int i = 0; i < Products.size(); i++) {
            System.out.println(Products.get(i).toString());
        }
        
        int quit = 0;
        int IntOption = 0;
        int IntAdd = 0;
        String junk = "";
        int IntSearch = 0;
        int optionFlag = 0;

        Scanner userInput = new Scanner(System.in);
        while(quit != 1) 
        {
            System.out.println("Welcome to our EStore. Please select an option: \n(1): Add an item\n(2): Search for an item\n(3): Quit\n");
            try 
            {
                IntOption = userInput.nextInt();
                junk = userInput.nextLine();
            } catch (Exception e) 
            {
                System.out.println("Please enter a number from one of the options");
                junk = userInput.nextLine();
            }

            //ADD
            if(IntOption == 1) 
            {
                System.out.println("ADDING item to EStore. Please select an option: \n(1): Add a Book\n(2): Add an Electronic\n");
               
                optionFlag = 0;
                while(optionFlag != 1) 
                {

                    try
                    {
                        IntAdd = userInput.nextInt();
                        junk = userInput.nextLine();
                        optionFlag = 1;
                    }
                    catch(Exception e)
                    {
                        System.out.println("Please enter a valid integer of either 1 or 2");
                        junk = userInput.nextLine();
                        optionFlag = 0; 

                    }
                }
                
                int idFlag = 0;
                int descriptionFlag = 0;
                int priceFlag = 0;
                int yearFlag = 0;
                int authorFlag = 0;
                int publisherFlag = 0;
                int makerFlag = 0;
                String sProductID = "";
                String Description = "";
                String sProductPrice = "";
                String sProductYear = "";
                int intProductYear = 0;
                float floatProductPrice = 0;
                int intProductID = 0;
                addFlag = 0;
                while(idFlag != 1) 
                {
                    System.out.println("Please add the product ID\n");
                    sProductID = new String();
                    sProductID = userInput.nextLine();
                            
                    try
                    {
                    intProductID = Integer.parseInt(sProductID);
                    idFlag = 1;
                    } catch (Exception e) 
                    {
                        System.out.println("Error: couldn't parse");
                        idFlag = 0;
                    }
                            
                    if(sProductID.length() != 6) 
                    {
                        System.out.println("Error: wrong number of digits (6)");
                        idFlag = 0;
                    } else if (sProductID.length() == 6 && idFlag == 1) 
                    {
                        for(int i = 0; i < Products.size(); i++)
                        {
                            if (Products.get(i).getProductID(sProductID) == 1)
                            {
                                System.out.println("We cannot accept this product ID as it already is in use for a book");   
                                idFlag = 0; 
                            } else {                                       
                                idFlag = 1;
                            }
                        }   
    
                        if(sProductID.length() == 6 && idFlag == 1)
                        {
                            idFlag = 1;
                            System.out.println("Product ID is ok");
                        } else {
                            idFlag = 0;
                        }

                    }   

                }
                
                while(descriptionFlag != 1) 
                {
                    System.out.println("Please add the product description\n");
                    Description = new String();
                    Description = userInput.nextLine();

                    if(Description.length() == 0) 
                    {
                        System.out.println("You need to print something");
                    } else {
                        descriptionFlag = 1;
                    }
                }

                while(priceFlag != 1) 
                {
                    System.out.println("Please add the product price\n");
                    sProductPrice = new String();
                    sProductPrice = userInput.nextLine();
                    try
                    {
                    floatProductPrice = Float.parseFloat(sProductPrice);
                    priceFlag = 1;
                    } catch (Exception e) 
                    {
                        System.out.println("Error: couldn't parse price");
                    }
                }

                while(yearFlag != 1) 
                {
                    System.out.println("Please add the product year\n");
                    sProductYear = userInput.nextLine();
                    try
                    {
                    intProductYear = Integer.parseInt(sProductYear);
                    yearFlag = 1;
                    } catch (Exception e) 
                    {
                        System.out.println("Error: couldn't parse year");
                    }

                    if(intProductYear > 9999 || intProductYear < 1000) 
                    {
                        System.out.println("Error: Not a valid year");
                    }
                }

                if(IntAdd == 1) 
                {
                    System.out.println("Enter the author of the book");
                    author = userInput.nextLine();
                    System.out.println("Enter the publisher of the book");
                    publisher = userInput.nextLine();
                    Products.add(new Book("Book", sProductID, Description, floatProductPrice, intProductYear, author, publisher));
                    System.out.println("\n************************");
                    System.out.println("\nBook added successfully!\n");
                    System.out.println("************************\n");
                    addFlag = 1;
                } else {
                    System.out.println("Enter the maker of the device");
                    maker = userInput.nextLine();
                    Products.add(new Electronic("Electronic", sProductID, Description, floatProductPrice, intProductYear, maker));
                    System.out.println("\n******************************");
                    System.out.println("\nElectronic added successfully!\n");
                    System.out.println("*******************************\n");
                    addFlag = 1;
                }

                    
                if(addFlag == 1)
            {
                StringTokenizer keywordsTokenizer = new StringTokenizer(Description);
                int tokenCount = keywordsTokenizer.countTokens();
                String keywordsTokens[] = new String[tokenCount];

                for(int i = 0; i < tokenCount; i++)
                {
                    keywordsTokens[i] = keywordsTokenizer.nextToken();
                    if(keywordsMap.containsKey(keywordsTokens[i]))
                    {
                        keywordsMap.get(keywordsTokens[i]).add(productCount);
                    } else {
                        ArrayList<Integer> temp = new ArrayList<Integer>();
                        temp.add(productCount);
                        keywordsMap.put(keywordsTokens[i].toLowerCase(),temp);
                    }
                }
                productCount++;
                addFlag = 0;
            }

            PrintWriter fileWriter = null;
            File myFile = null;
            try{
                myFile = new File(args[0]);
                fileWriter = new PrintWriter(new FileOutputStream(myFile,true));
            } catch (FileNotFoundException e) {
                System.out.println("File does not exist");
                System.exit(0);
            }

            if(idFlag != 0) 
            {
                if(IntAdd == 1)
                {
                    fileWriter.println("type = Book");
                } else if(IntAdd == 2){
                    fileWriter.println("type = Electronic");
                }

                fileWriter.println("productID = \"" + sProductID + "\"");
                fileWriter.println("description = \"" + Description + "\"");
                fileWriter.println("price = \"" + floatProductPrice + "\"");
                fileWriter.println("year = \"" + intProductYear + "\"");

                if(IntAdd == 1)
                {
                    fileWriter.println("author = \"" + author + "\"");
                    fileWriter.println("publisher = \"" + publisher + "\"");
                } else if(IntAdd == 2)
                {
                    fileWriter.println("maker = \"" + maker + "\"");
                }
            }
            fileWriter.close(); 

                  
            
            }
            
            //SEARCH
            if(IntOption == 2) {
                int intProductID = 0;
                System.out.println("SEARCHING for item in EStore.\n");
                String sProductID = new String();

                int searchFlag = 0;
                while(searchFlag == 0) {
                    System.out.println("Please add the product ID\n");
                    sProductID = userInput.nextLine();

                    if(sProductID.length() == 0) {
                        sProductID= "";
                        searchFlag = 1;
                    } else {
                        try {
                        intProductID = Integer.parseInt(sProductID);
                        searchFlag = 1;
                        } catch (Exception e) {
                            System.out.println("Error with ID");
                            searchFlag = 0;
                        }

                        if(sProductID.length() != 6) {
                            System.out.println("Enter a 6 digit number");
                            searchFlag = 0;
                        } else if(sProductID.length() == 6 && searchFlag == 1) {
                            searchFlag = 1;
                        } else {
                            searchFlag = 0;
                        }
                    }
                }

                searchFlag = 0;

                while(searchFlag == 0) {
                System.out.println("Please add the product description\n");
                productDescription = new String();
                productDescription = userInput.nextLine();

                if(productDescription.length() == 0) {
                    productDescription = "";
                    searchFlag = 1;
                }

                searchFlag = 1;

                }

                String searchYear = "";
                int start = 0;
                int end = 0;
                String delimiter = "-";
                int specificYearFlag = 0;

                searchFlag = 0;
                while(searchFlag == 0) {
                    System.out.println("Enter year: startyear-endyear    startyear-    -endyear    specific year");
                    searchYear = userInput.nextLine();
                    StringTokenizer yearToken = new StringTokenizer(searchYear, delimiter);
                    String token = yearToken.nextToken();

                    if(searchYear.length() == 0) {
                        start = 1000;
                        end = 9999;
                        searchFlag = 1;
                    } else if(searchYear.length() == 5) 
                    {

                        if(searchYear.charAt(4) == '-') {

                            try{

                                start = Integer.parseInt(token);
                                end = 9999;
                                searchFlag = 1;

                            } catch (Exception e) {

                                System.out.println("Couldn't parse year");
                                searchFlag = 0;
                            }

                        } else if(searchYear.charAt(0) == '-') {

                            try{
                                start = 1000;
                                end = Integer.parseInt(token);
                                searchFlag = 1;
                            } catch (Exception e) {
                                System.out.println("couldn't parse year");
                                searchFlag = 0;
                            }

                        } else if(searchYear.charAt(0) != '-' || searchYear.charAt(4) != '-') 
                        {
                        System.out.println("invalid");
                        searchFlag = 0;
                        } 
                        
                    } else if(searchYear.length() == 4) {
                        try{
                            start = Integer.parseInt(searchYear);
                            end = 9999;
                            searchFlag = 1;
                            specificYearFlag = 1;
                        } catch (Exception e) {
                            System.out.println("invalid input");
                            searchFlag = 0;
                        }
                    }  else {
                        System.out.println("invalid input");
                        searchFlag = 0;
                    } 

                    if(start > end || start < 1000 || end > 9999) {
                        System.out.println("invalid year input");
                        searchFlag = 0;
                    }
                    System.out.println("\nYear entered successfully, from: " + start + "-" + end + "\n");

                }

                Product.searchProduct(sProductID, productDescription, start, end, specificYearFlag, keywordsMap, Products);
            }

            //QUIT
            if(IntOption == 3) {
                System.out.println("\n*******************************\n");
                System.out.println("\nThank you for shopping with us!\n");
                System.out.println("\n*******************************\n");

                System.out.println(keywordsMap);
                quit = 1;
            }




        }*/
        String file = args[0];

        MyFrame frame = new MyFrame(keywordsMap, Products, file);
        frame.setVisible(true);

    }
}


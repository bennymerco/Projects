package eStoreSearch;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.*;

public class Product
{
    private String type;
    private String productID;
    private String description;
    private float price;
    private int year;

    public Product() 
    {
        type = "";
        productID = "";
        description = "";
        price = 0;
        year = 0;
    }

    /**
     * Initializes the variables in product
     * @param type          type of product
     * @param productID     id of product
     * @param description   description of product
     * @param price         price of product
     * @param year          year of product
     */
    public Product(String type, String productID, String description, float price, int year) 
    {
        this.type = type;
        this.productID = productID;
        this.description = description;
        this.price = price;
        this.year = year;
    }

    /**
     * checks if product ID is equal to one searched
     * @param id    id of product
     * @return      if product id is equal
     */
    public int getProductID(String id) 
    {
        if(id.equals(productID)) 
        {
            return 1;
        } else {
            return 0;
        }
    }

  
    /**
     * Gets product ID
     * @return  product ID
     */
    public String getID() 
    {
        return productID;
    }

    /**
     * Gets product year
     * @return  product year
     */
    public int getyear() 
    {
        return year;
    }

    /**
     * Searches for product
     * @param sProductID    string of product id
     * @param sKeywords     string of description
     * @param sStart        string of start year
     * @param sEnd          string of end year
     * @return              if product is found
     */
    public int searchProduct(String sProductID, String sKeywords, int sStart, int sEnd) {
        int totalReturn = 0;
        String delimiters = ",?!. ";
    
        if (sProductID.length() == 0) {
            System.out.print("1");
            totalReturn++;
        } else if(sProductID.equals(productID)) {
            System.out.print("2");
            totalReturn++;
        } else {
            return (-1);
        }
    
        
            if(year >= sStart && year <= sEnd) {
                System.out.print("3");
                totalReturn++;
            }
        
    
        if(sKeywords.length() == 0) {
            System.out.print("4");
            totalReturn++;
        } else if(sKeywords.length() != 0) {
            int match = 0;
            StringTokenizer keyTokenizer = new StringTokenizer(sKeywords, "!?., ");
            int arraySize = keyTokenizer.countTokens();
    
            System.out.println("array size  " + arraySize);
    
            String keyTokens[] = new String[arraySize];
            
            for(int i = 0; i < arraySize; i++) {
                keyTokens[i] = keyTokenizer.nextToken("!?., ");
            }
    
            String temp = new String();
            for(int i = 0; i < arraySize; i++) {
                temp = keyTokens[i].toLowerCase();
    
                if(description.toLowerCase().contains(temp)) {
                    System.out.print("5");
                    totalReturn++;
                }
            }
    
        }
    
        return (totalReturn);
    }


    public String toString() 
    {
        return "\nType: " + type + "\nProduct ID: " + productID + "\nDescription: "
        + description + "\nPrice: " + price + "\nYear: "
        + year;
    }



}

class Book extends Product
{

    private String author;
    private String publisher;
    
    public Book() 
    {
        author = "";
        publisher = "";

    }
    
    public Book(String type, String productID, String description, float price, int year, String author, String publisher) 
    {
        super(type, productID, description, price, year);
        this.author = author;
        this.publisher = publisher;
    }

    public String toString() 
    {
        return (super.toString() + "\nAuthor: " + author + "\nPublisher: " + publisher + "\n");
    }

}

class Electronic extends Product
{

    private String maker;
    
    public Electronic() 
    {
        
        maker = "";
    }
    
    public Electronic(String type, String productID, String description, float price, int year, String maker) 
    {
        super(type, productID, description, price, year);
        this.maker = maker;
    }

    public String toString() 
    {
        return (super.toString() + "\nMaker: " + maker + "\n");
    }

}
    